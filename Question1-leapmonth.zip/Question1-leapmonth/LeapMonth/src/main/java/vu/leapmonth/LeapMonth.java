/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package vu.leapmonth;

/**
 *
 * @author khalid
 */
import java.util.Scanner;

public class LeapMonth {
    private int year;
    private int month;

    public LeapMonth(int year, int month) {
        this.year = year;
        this.month = month;
    }

    public boolean isLeapMonth() {
        return (year % 4 == 0) && (month % 100 != 0) || (year % 400 == 0);
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter the year: ");
        int year = scanner.nextInt();

        System.out.println("Enter the month (1-12): ");
        int month = scanner.nextInt();

        LeapMonth leapMonth = new LeapMonth(year, month);

        if (leapMonth.isLeapMonth()) {
            System.out.println("The month is a leap month.");
        } else {
            System.out.println("The month is not a leap month.");
}
}
}

